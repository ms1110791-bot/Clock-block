package com.clock.app

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.content.Intent

class BlockService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var start = 0L

    private val tick = object : Runnable {
        override fun run() {
            if (start == 0L) return
            if (P.blocked(this@BlockService, System.currentTimeMillis() - start)) kick()
            else h.postDelayed(this, 3000)
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == "com.android.systemui" || pkg.contains("inputmethod")) return
        if (P.isFF(this, pkg)) {
            if (start == 0L) {
                if (P.blocked(this)) {
                    kick()
                    return
                }
                start = System.currentTimeMillis()
                h.postDelayed(tick, 3000)
            }
        } else {
            stopSession()
        }
    }

    private fun stopSession() {
        if (start != 0L) {
            P.addUsed(this, System.currentTimeMillis() - start)
            start = 0L
            h.removeCallbacks(tick)
        }
    }

    private fun kick() {
        stopSession()
        // Sirf Home par bhejta hai, koi toast/popup/logo nahi dikhata
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    // System jab bhi service chalu/restart kare, Clock notification bhi wapas chalu
    override fun onServiceConnected() {
        super.onServiceConnected()
        try {
            startForegroundService(Intent(this, ClockService::class.java))
        } catch (e: Exception) {
            // ignore
        }
    }

    override fun onInterrupt() {
        stopSession()
    }
}
