package com.clock.app

import android.content.Context

object P {
    val PKGS = setOf("com.dts.freefireth", "com.dts.freefiremax")

    fun sp(c: Context) = c.getSharedPreferences("c", Context.MODE_PRIVATE)

    fun used(c: Context): Long {
        val s = sp(c)
        val now = System.currentTimeMillis()
        if (now - s.getLong("ws", 0) >= 86400000L) {
            s.edit().putLong("ws", now).putLong("used", 0).apply()
        }
        return s.getLong("used", 0)
    }

    fun addUsed(c: Context, ms: Long) {
        val u = used(c)
        sp(c).edit().putLong("used", u + ms).apply()
    }

    fun blocked(c: Context, extra: Long = 0): Boolean {
        val s = sp(c)
        if (!s.getBoolean("on", false)) return false
        val until = s.getLong("until", 0)
        val lim = s.getInt("limit", 0)
        if (until > System.currentTimeMillis()) return true
        if (lim > 0) return used(c) + extra >= lim * 60000L
        return until == 0L
    }
}
