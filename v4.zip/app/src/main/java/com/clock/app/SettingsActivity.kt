package com.clock.app

import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {

    private lateinit var tvStatus: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_settings)

        val s = P.sp(this)
        val sw = findViewById<Switch>(R.id.swBlock)
        val dur = findViewById<EditText>(R.id.etDuration)
        val lim = findViewById<EditText>(R.id.etLimit)
        tvStatus = findViewById(R.id.tvStatus)

        sw.isChecked = s.getBoolean("on", false)
        val l = s.getInt("limit", 0)
        if (l > 0) lim.setText(l.toString())

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        wire(findViewById(R.id.chipsDur), dur)
        wire(findViewById(R.id.chipsLim), lim)

        findViewById<View>(R.id.btnSave).setOnClickListener {
            val now = System.currentTimeMillis()
            if (s.getBoolean("on", false) && s.getLong("until", 0) > now) {
                Toast.makeText(this, "Locked until timer ends", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val m = dur.text.toString().toLongOrNull() ?: 0L
            val lm = lim.text.toString().toIntOrNull() ?: 0
            s.edit()
                .putBoolean("on", sw.isChecked)
                .putLong("until", if (sw.isChecked && m > 0) now + m * 60000L else 0L)
                .putInt("limit", lm)
                .apply()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            refresh()
        }

        findViewById<View>(R.id.btnService).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<View>(R.id.btnNotif).setOnClickListener {
            try {
                startActivity(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                )
            } catch (e: Exception) {
                openAppInfo()
            }
        }

        findViewById<View>(R.id.btnBattery).setOnClickListener {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }

        findViewById<View>(R.id.btnAppInfo).setOnClickListener { openAppInfo() }
    }

    private fun openAppInfo() {
        startActivity(
            Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:$packageName")
            )
        )
    }

    private fun wire(group: ViewGroup, et: EditText) {
        for (i in 0 until group.childCount) {
            val c = group.getChildAt(i)
            c.setOnClickListener { et.setText(c.tag.toString()) }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // Permission mil gayi to button hara (green) ho jata hai
    private fun mark(id: Int, ok: Boolean, onText: String, offText: String) {
        val v = findViewById<TextView>(id)
        if (ok) {
            v.setBackgroundResource(R.drawable.bg_button_ok)
            v.setTextColor(getColor(R.color.on_accent))
            v.text = onText
        } else {
            v.setBackgroundResource(R.drawable.bg_button_ghost)
            v.setTextColor(getColor(R.color.accent))
            v.text = offText
        }
    }

    private fun refresh() {
        val s = P.sp(this)
        val en = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        val accOn = en.contains(packageName)
        val battOk = try {
            getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        } catch (e: Exception) {
            false
        }
        val notifOk = try {
            getSystemService(NotificationManager::class.java).areNotificationsEnabled()
        } catch (e: Exception) {
            false
        }

        mark(R.id.btnService, accOn, "✓ Background service ON", "Enable background service")
        mark(R.id.btnNotif, notifOk, "✓ Notifications allowed", "Allow notifications")
        mark(R.id.btnBattery, battOk, "✓ Battery unrestricted", "Keep always running (battery)")

        val now = System.currentTimeMillis()
        val left = (s.getLong("until", 0) - now) / 60000
        val ff = s.getLong("ffts", 0)
        var t = "Background service: " + (if (accOn) "ON" else "OFF (enable it below)")
        if (left > 0) t += "\nLocked: $left min left"
        t += "\nUsed in last 24h: ${P.used(this) / 60000} min"
        t += "\nFree Fire last detected: " + (if (ff == 0L) "never" else "${(now - ff) / 1000}s ago")
        t += "\nLast app seen: " + (s.getString("lp", null) ?: "none yet")
        tvStatus.text = t
    }
}
