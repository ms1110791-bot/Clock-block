package com.clock.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

// Har 1 minute me chalta hai aur Clock service ko wapas chalu karne ki koshish karta hai
class WatchdogReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try {
            context.startForegroundService(Intent(context, ClockService::class.java))
        } catch (e: Exception) {
            // ignore
        }
        schedule(context, 60000L)
    }

    companion object {
        fun schedule(c: Context, delay: Long) {
            try {
                val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val pi = PendingIntent.getBroadcast(
                    c, 7, Intent(c, WatchdogReceiver::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + delay, pi)
            } catch (e: Exception) {
                // ignore
            }
        }
    }
}
