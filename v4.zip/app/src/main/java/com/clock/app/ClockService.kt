package com.clock.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ClockService : Service() {
    private val h = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            getSystemService(NotificationManager::class.java).notify(ID, build())
            h.postDelayed(this, 30000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CH, "Clock", NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
        startForeground(ID, build())
        h.removeCallbacks(tick)
        h.postDelayed(tick, 30000L)
        WatchdogReceiver.schedule(this, 60000L)
        return START_STICKY
    }

    // Recents se hatane par 1 second me wapas chalu karne ka alarm
    override fun onTaskRemoved(rootIntent: Intent?) {
        WatchdogReceiver.schedule(this, 1000L)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        super.onDestroy()
    }

    private fun build(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Clock")
            .setContentText(time)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    companion object {
        const val ID = 1
        const val CH = "clock"
    }
}
