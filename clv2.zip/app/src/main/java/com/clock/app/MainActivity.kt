package com.clock.app

import android.Manifest
import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private class A(var t: String, var on: Boolean)

    private val alarms = mutableListOf<A>()
    private lateinit var list: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        list = findViewById(R.id.alarmList)

        load()
        render()

        findViewById<View>(R.id.btnMenu).setOnClickListener { v ->
            val pm = PopupMenu(this@MainActivity, v)
            pm.menu.add(0, 1, 0, "Settings")
            pm.setOnMenuItemClickListener {
                startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
                true
            }
            pm.show()
        }

        findViewById<View>(R.id.fabAdd).setOnClickListener {
            TimePickerDialog(this, { _, hh, mm ->
                alarms.add(A("%02d:%02d".format(hh, mm), true))
                alarms.sortBy { it.t }
                save()
                render()
            }, 7, 0, true).show()
        }

        val soon = View.OnClickListener {
            Toast.makeText(this, "Not available", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.navClock).setOnClickListener(soon)
        findViewById<View>(R.id.navTimer).setOnClickListener(soon)
        findViewById<View>(R.id.navStopwatch).setOnClickListener(soon)

        startClockService()
    }

    private fun startClockService() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        try {
            startForegroundService(Intent(this, ClockService::class.java))
        } catch (e: Exception) {
            // ignore
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        startClockService()
    }

    private fun prefs() = getSharedPreferences("alarms", MODE_PRIVATE)

    private fun load() {
        alarms.clear()
        val raw = prefs().getString("list", "06:30|0;07:00|0") ?: ""
        for (p in raw.split(";")) {
            val x = p.split("|")
            if (x.size == 2) alarms.add(A(x[0], x[1] == "1"))
        }
    }

    private fun save() {
        val raw = alarms.joinToString(";") { it.t + "|" + (if (it.on) "1" else "0") }
        prefs().edit().putString("list", raw).apply()
    }

    private fun render() {
        list.removeAllViews()
        for (a in alarms) {
            val row = layoutInflater.inflate(R.layout.item_alarm, list, false)
            row.findViewById<TextView>(R.id.tvTime).text = a.t
            val sw = row.findViewById<Switch>(R.id.swAlarm)
            sw.isChecked = a.on
            sw.setOnCheckedChangeListener { _, c ->
                a.on = c
                save()
            }
            row.setOnLongClickListener {
                alarms.remove(a)
                save()
                render()
                true
            }
            list.addView(row)
        }
    }
}
