package com.clock.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {

    private lateinit var tvStatus: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_settings)

        val s = P.sp(this)
        val sw = findViewById<Switch>(R.id.swBlock)
        val dur = findViewById<EditText>(R.id.etDuration)
        val lim = findViewById<EditText>(R.id.etLimit)
        tvStatus = findViewById(R.id.tvStatus)

        sw.isChecked = s.getBoolean("on", false)
        val l = s.getInt("limit", 0)
        if (l > 0) lim.setText(l.toString())

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        wire(findViewById(R.id.chipsDur), dur)
        wire(findViewById(R.id.chipsLim), lim)

        findViewById<View>(R.id.btnSave).setOnClickListener {
            val now = System.currentTimeMillis()
            if (s.getBoolean("on", false) && s.getLong("until", 0) > now) {
                Toast.makeText(this, "Locked until timer ends", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val m = dur.text.toString().toLongOrNull() ?: 0L
            val lm = lim.text.toString().toIntOrNull() ?: 0
            s.edit()
                .putBoolean("on", sw.isChecked)
                .putLong("until", if (sw.isChecked && m > 0) now + m * 60000L else 0L)
                .putInt("limit", lm)
                .apply()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            refresh()
        }

        findViewById<View>(R.id.btnService).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    private fun wire(group: ViewGroup, et: EditText) {
        for (i in 0 until group.childCount) {
            val c = group.getChildAt(i)
            c.setOnClickListener { et.setText(c.tag.toString()) }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val s = P.sp(this)
        val en = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        val left = (s.getLong("until", 0) - System.currentTimeMillis()) / 60000
        var t = "Background service: " + (if (en.contains(packageName)) "ON" else "OFF (enable it below)")
        if (left > 0) t += "\nLocked: $left min left"
        t += "\nUsed in last 24h: ${P.used(this) / 60000} min"
        tvStatus.text = t
    }
}
