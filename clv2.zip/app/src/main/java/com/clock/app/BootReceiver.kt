package com.clock.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try {
            context.startForegroundService(Intent(context, ClockService::class.java))
        } catch (e: Exception) {
            // ignore, accessibility service restarts on its own
        }
    }
}
