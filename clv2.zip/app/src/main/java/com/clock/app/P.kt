package com.clock.app

import android.content.Context

object P {
    // Pehle ye teen/major packages, phir baaki sab variants
    private val CORE = setOf("com.dts.freefireth", "com.dts.freefiremax")
    private val cache = HashMap<String, Boolean>()

    // True agar package ka naam ya ऐप ka label "freefire / free fire" wala ho
    // (Free Fire, MAX, India, Advance Server, aur baaki variants)
    fun isFF(c: Context, pkg: String): Boolean {
        if (pkg in CORE || pkg.contains("freefire", ignoreCase = true)) return true
        cache[pkg]?.let { return it }
        val r = try {
            val pm = c.packageManager
            val label = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            label.lowercase().replace(" ", "").contains("freefire")
        } catch (e: Exception) {
            false
        }
        cache[pkg] = r
        return r
    }

    fun sp(c: Context) = c.getSharedPreferences("c", Context.MODE_PRIVATE)

    fun used(c: Context): Long {
        val s = sp(c)
        val now = System.currentTimeMillis()
        if (now - s.getLong("ws", 0) >= 86400000L) {
            s.edit().putLong("ws", now).putLong("used", 0).apply()
        }
        return s.getLong("used", 0)
    }

    fun addUsed(c: Context, ms: Long) {
        val u = used(c)
        sp(c).edit().putLong("used", u + ms).apply()
    }

    fun blocked(c: Context, extra: Long = 0): Boolean {
        val s = sp(c)
        if (!s.getBoolean("on", false)) return false
        val until = s.getLong("until", 0)
        val lim = s.getInt("limit", 0)
        if (until > System.currentTimeMillis()) return true
        if (lim > 0) return used(c) + extra >= lim * 60000L
        return until == 0L
    }
}
